import numpy as np

from sklearn.metrics.pairwise import euclidean_distances




def get_noise_dbscan(X, eps=0.0, min_samples=0):
    
    core_point_indices, noise_point_indices = None, None
    
    #########################################################################################
    ### Your code starts here ###############################################################
    
    ### 2.1 a) Identify the indices of all core points

    
    
    ### Your code ends here #################################################################
    #########################################################################################
    
    
    #########################################################################################
    ### Your code starts here ###############################################################
    
    ### 2.1 b) Identify the indices of all noise points ==> noise_point_indices
    

    
    ### Your code ends here #################################################################
    #########################################################################################
    
    return core_point_indices, noise_point_indices